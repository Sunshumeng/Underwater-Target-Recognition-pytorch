import argparse
import numpy as np
from datetime import datetime
import torch
from prettytable import PrettyTable
from torch.nn import CrossEntropyLoss
from torch.optim import Adam
from tqdm import tqdm
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import os
import pandas as pd
import matplotlib.pyplot as plt
from model import simplenet
from model.simplenet import AudioUNetWithAttention

data_folder = "D:\音频分类\Pytorch-AudioClassification-master-main\data\音频数据"
label_csv_path = "D:\音频分类\Pytorch-AudioClassification-master-main\data\scatter/refer.csv"

# 存储数据和标签的列表
data_list = []
labels_list = []

# 遍历数据文件夹
for filename in os.listdir(data_folder):
    if filename.endswith(".txt"):
        file_path = os.path.join(data_folder, filename)
        with open(file_path, "r", encoding="utf-8") as f:
            data = f.read()
            data_list.append(data)

# 读取标签 CSV 文件
labels_df = pd.read_csv(label_csv_path)

# 处理标签数据
for filename in os.listdir(data_folder):
    if filename.endswith(".txt"):
        file_prefix = os.path.splitext(filename)[0]
        label = labels_df[labels_df["filename"] == file_prefix]["label"].values[0]
        labels_list.append(label)

# 将数据转换为 PyTorch 张量
data_tensor = torch.tensor(data_list, dtype=torch.float)
labels_tensor = torch.tensor(labels_list, dtype=torch.long)


class SoundDataSet(torch.utils.data.Dataset):
    def __init__(self, data_dir, csv_path):
        self.df = pd.read_csv(csv_path, encoding='utf-8')
        self.data_dir = data_dir

    def __len__(self):
        return len(self.df)

    def __getitem__(self, index):
        label = self.df['label'][index]
        data = np.load(os.path.join(self.data_dir, self.df['filepath'][index]))
        # 在这里将标签转换为独热编码形式
        num_classes = 32  # 根据实际类别数调整
        one_hot_label = torch.nn.functional.one_hot(torch.tensor(label), num_classes=num_classes)
        return data, one_hot_label


data_dir = "D:\音频分类\Pytorch-AudioClassification-master-main\data\音频数据"
csv_path = "D:\音频分类\Pytorch-AudioClassification-master-main\data\scatter/refer.csv"
batch_size = 16
train_percent = 0.8

dataset = SoundDataSet(data_dir, csv_path)
num_sample = len(dataset)
num_train = int(train_percent * num_sample)
num_valid = num_sample - num_train
train_ds, valid_ds = torch.utils.data.random_split(dataset, [num_train, num_valid])
train_dl = torch.utils.data.DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=4, pin_memory=True,
                                       persistent_workers=True)
valid_dl = torch.utils.data.DataLoader(valid_ds, batch_size=batch_size, shuffle=False, num_workers=4, pin_memory=True,
                                       persistent_workers=True)


# 导入参数
def get_args():
    parser = argparse.ArgumentParser(description='Audio classification parameter configuration(train)')
    parser.add_argument(
        '-t',
        type=str,
        default='pytorch-audioclassification-master',
        help="the theme's name of your task"
    )
    parser.add_argument(
        '-dp',
        type=str,
        default=r'D:\音频分类\Pytorch-AudioClassification-master-main\data\音频数据',
        help="train's directory"
    )
    parser.add_argument(
        '-classes',
        type=list,
        default=[r'D:\音频分类\Pytorch-AudioClassification-master-main\data\scatter\classes.txt'],
        help="classes list"
    )

    parser.add_argument(
        '-infop',
        type=str,
        default=r'D:\音频分类\Pytorch-AudioClassification-master-main\data\scatter\refer.csv',
        help="DIF(folder information file)'s path"
    )

    parser.add_argument(
        '-tp',
        type=float,
        default=0.8,
        help="train folder's percent"
    )
    parser.add_argument(
        '-bs',
        type=int,
        default=16,
        help="folder's batch size"
    )
    parser.add_argument(
        '-cn',
        type=int,
        default=32,
        help='the number of classes'
    )
    parser.add_argument(
        '-e',
        type=int,
        default=50,
        help='epoch'
    )
    parser.add_argument(
        '-lr',
        type=float,
        default=0.01,
        help='learning rate'
    )
    parser.add_argument(
        '-ld',
        type=str,
        default='D:\音频分类\Pytorch-AudioClassification-master-main\workdir',
        help="the training log's save directory"
    )

    return parser.parse_args()


def main(model_output=None, valid_loss=None, num_epochs=None):
    args = get_args()
    # 训练设备信息
    device_table = ""
    if torch.cuda.is_available():
        device_table = PrettyTable(['number of gpu', 'applied gpu index', 'applied gpu name'], min_table_width=80)
        gpu_num = torch.cuda.device_count()
        gpu_index = torch.cuda.current_device()
        gpu_name = torch.cuda.get_device_name()
        device_table.add_row([str(gpu_num), str(gpu_index), str(gpu_name)])
        print('{}\n'.format(device_table))
    else:
        print("Using cpu......")
        device_table = 'CPU'
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    # 数据集信息
    samples_num = 148
    train_num = 118
    valid_num = samples_num - train_num
    args_tp = train_num / samples_num

    print(f"Number of samples: {samples_num}")
    print(f"Number of training samples: {train_num}")
    print(f"Number of validation samples: {valid_num}")
    print(f"Training set percentage: {args_tp}")

    dataset_table = PrettyTable(['number of samples', 'train number', 'valid number', 'percent'], min_table_width=80)
    dataset_table.add_row([samples_num, train_num, valid_num, args_tp])     
    print("{}\n".format(dataset_table))
    # 训练组件配置
    print("Classes information:")
    classes_table = PrettyTable(args.classes, min_table_width=80)
    classes_table.add_row(range(len(args.classes)))
    print("{}\n".format(classes_table))
    print("Train information:")
    model = AudioUNetWithAttention(num_classes=args.cn).to(device)
    optimizer = Adam(params=model.parameters(), lr=args.lr)
    # 可以考虑使用其他损失函数或者对交叉熵损失函数进行调整
    loss_fn = CrossEntropyLoss()
    train_table = PrettyTable(['theme', 'batch size', 'epoch', 'learning rate', 'directory of log'],
                              min_table_width=120)
    train_table.add_row([args.t, args.bs, args.e, args.lr, args.ld])
    print('{}\n'.format(train_table))
    # 开始训练
    losses = []
    accuracies = []
    precisions = []
    recalls = []
    f1s = []
    aucs = []
    maps = []
    best_f1 = 0
    best_checkpoint_path = os.path.join(args.ld, "best_f1.pth")

    st = datetime.now()
    for epoch in range(args.e):
        prediction = []
        label = []
        score = []

        model.train()
        train_bar = tqdm(iter(train_dl), ncols=150, colour='red')
        train_loss = 0.
        i = 0
        num_classes = 32  # 根据实际类别数调整

        for train_data in train_bar:
            x_train, y_train_expanded= train_data
            x_train = x_train.to(device)

            print(f"Original shape of y_train: {y_train_expanded.shape}")
            if y_train_expanded.dim() == 1:
                y_train_onehot = torch.nn.functional.one_hot(y_train_expanded, num_classes=num_classes).float()
                y_train_expanded = y_train_onehot.unsqueeze(2)
            output = model(x_train)
            print(f"Shape of model output tensor: {output.shape}")
            print(f"Shape of reshaped target tensor: {y_train_expanded.shape}")

            loss = loss_fn(output, y_train_expanded)
            optimizer.zero_grad()
            train_loss += loss.clone().detach().cpu().numpy()
            loss.backward()
            optimizer.step()
            train_bar.set_description("Epoch:{}/{} Step:{}/{}".format(epoch + 1, args.e, i + 1, len(train_dl)))
            train_bar.set_postfix({"train loss": "%.3f" % loss.data})
            i += 1

        train_loss = train_loss / i
        losses.append(train_loss)

        model.eval()
        valid_bar = tqdm(iter(valid_dl), ncols=150, colour='red')
        valid_acc = 0.
        valid_pre = 0.
        valid_recall = 0.
        valid_f1 = 0.
        valid_auc = 0.
        valid_ap = 0.
        i = 0
        for valid_data in valid_bar:
            x_valid, y_valid = valid_data
            x_valid = x_valid.to(device)
            y_valid_ = y_valid.clone().detach().numpy().tolist()
            output = model(x_valid)
            output_ = output.clone().detach().cpu()
            _, pred = torch.max(output_, 1)
            pred_ = pred.clone().detach().numpy().tolist()
            output_ = output_.numpy().tolist()
            valid_bar.set_description("Epoch:{}/{} Step:{}/{}".format(epoch + 1, args.e, i + 1, len(valid_dl)))
            prediction = prediction + pred_
            label = label + y_valid_
            score = score + output_
            i += 1
        # 最后得到的 i 是一次迭代中的样本数批数
        # 每一次 epoch 计算一次
        valid_acc = accuracy_score(y_true=label, y_pred=prediction)
        valid_pre = precision_score(y_true=label, y_pred=prediction, average='weighted', zero_division=1)
        valid_recall = recall_score(y_true=label, y_pred=prediction, average='weighted', zero_division=1)
        valid_f1 = f1_score(y_true=label, y_pred=prediction, average='weighted')

        accuracies.append(valid_acc)
        precisions.append(valid_pre)
        recalls.append(valid_recall)
        f1s.append(valid_f1)

        if valid_f1 > best_f1:
            best_f1 = valid_f1
            torch.save(model.state_dict(), best_checkpoint_path)
        indicator_table = PrettyTable(['Accuracy', 'Precision', 'Recall', 'F1'])
        indicator_table.add_row([valid_acc, valid_pre, valid_recall, valid_f1])
        print('\n{}\n'.format(indicator_table))
    et = datetime.now()

    # 绘制训练曲线
    plt.figure(figsize=(12, 6))
    plt.subplot(2, 2, 1)
    plt.plot(range(args.e), losses, label='Train Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()

    plt.subplot(2, 2, 2)
    plt.plot(range(args.e), accuracies, label='Validation Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()

    plt.subplot(2, 2, 3)
    plt.plot(range(args.e), precisions, label='Precision')
    plt.xlabel('Epoch')
    plt.ylabel('Precision')
    plt.legend()

    plt.subplot(2, 2, 4)
    plt.plot(range(args.e), recalls, label='Recall')
    plt.xlabel('Epoch')
    plt.ylabel('Recall')
    plt.legend()

    plt.tight_layout()
    plt.show()

    # 保存 final_model.pth
    final_model_path = os.path.join(args.ld, "final_model.pth")
    torch.save(model.state_dict(), final_model_path)

    # 假设 log_generator 函数的实现与之前相同
    log_generator(args.t, args.infop, args.classes, x_train.shape, et - st, dataset_table, classes_table, device_table,
                  train_table, optimizer, model, args.e, [losses, accuracies, precisions, recalls, f1s],
                  args.ld, best_checkpoint_path)
    target_sample = target[:32]  # 打印前 10 个目标值
    print("Target values:", target_sample)
    num_classes = model_output.shape[1]  # 获取模型输出的类别数
    print("Number of classes:", num_classes)

    # 生成.onnx 文件
    dummy_input = torch.randn(1, *x_train.shape[1:]).to(device)
    torch.onnx.export(model, dummy_input, os.path.join(args.ld, "final_model.onnx"))
    torch.onnx.export(model, dummy_input, os.path.join(args.ld, "best_f1.onnx"))


if __name__ == "__main__":
    main()
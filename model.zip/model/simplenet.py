from torch import nn
import torch
import torch.nn.functional as F

class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction_ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc1 = nn.Conv2d(in_channels, in_channels // reduction_ratio, kernel_size=1, bias=False)
        self.relu = nn.ReLU()
        self.fc2 = nn.Conv2d(in_channels // reduction_ratio, in_channels, kernel_size=1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu(self.fc1(self.max_pool(x))))
        return self.sigmoid(avg_out + max_out) * x

class AudioUNetWithAttention(nn.Module):
    def __init__(self, num_classes):
        super(AudioUNetWithAttention, self).__init__()
        # Encoder
        self.enc1 = nn.Sequential(
            nn.Conv2d(2, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU()
        )
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.enc2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU()
        )
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.enc3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU()
        )
        self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.enc4 = nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU()
        )
        self.pool4 = nn.MaxPool2d(kernel_size=2, stride=2)
        # Bottleneck
        self.bottleneck = nn.Sequential(
            nn.Conv2d(512, 1024, kernel_size=3, padding=1),
            nn.BatchNorm2d(1024),
            nn.ReLU(),
            nn.Conv2d(1024, 1024, kernel_size=3, padding=1),
            nn.BatchNorm2d(1024),
            nn.ReLU()
        )
        # Decoder with attention
        self.upconv4 = nn.ConvTranspose2d(1024, 512, kernel_size=2, stride=2)
        self.dec4 = nn.Sequential(
            nn.Conv2d(1024, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU()
        )
        self.attention4 = ChannelAttention(512)
        self.upconv3 = nn.ConvTranspose2d(512, 256, kernel_size=2, stride=2)
        self.dec3 = nn.Sequential(
            nn.Conv2d(512, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU()
        )
        self.attention3 = ChannelAttention(256)
        self.upconv2 = nn.ConvTranspose2d(256, 128, kernel_size=2, stride=2)
        self.dec2 = nn.Sequential(
            nn.Conv2d(256, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU()
        )
        self.attention2 = ChannelAttention(128)
        self.upconv1 = nn.ConvTranspose2d(128, 64, kernel_size=2, stride=2)
        self.dec1 = nn.Sequential(
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU()
        )

        self.attention1 = ChannelAttention(64)
        # Final classification layer
        self.global_avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.final_conv = nn.Conv2d(64, num_classes, kernel_size=1)

    def forward(self, x):
        # Encoder
        enc1 = self.enc1(x)
        pool1 = self.pool1(enc1)
        enc2 = self.enc2(pool1)
        pool2 = self.pool2(enc2)
        enc3 = self.enc3(pool2)
        pool3 = self.pool3(enc3)
        enc4 = self.enc4(pool3)
        pool4 = self.pool4(enc4)

        # Bottleneck
        bottleneck = self.bottleneck(pool4)
        # Decoder
        upconv4 = self.upconv4(bottleneck)
        enc4_shape = enc4.shape
        upconv4_shape = upconv4.shape
        if enc4_shape[2:] != upconv4_shape[2:]:
            # Calculate padding or cropping values
            diff_h = enc4_shape[2] - upconv4_shape[2]
            diff_w = enc4_shape[3] - upconv4_shape[3]
            if diff_h > 0 or diff_w > 0:
                # If enc4 is larger, crop enc4
                enc4 = enc4[:, :, :upconv4_shape[2], :upconv4_shape[3]]
            else:
                # If upconv4 is larger, pad enc4
                pad_h = abs(diff_h) // 2
                pad_w = abs(diff_w) // 2
                enc4 = F.pad(enc4, (pad_w, pad_w, pad_h, pad_h))

        print(f"Shape of enc4: {enc4.shape}")
        print(f"Shape of upconv4: {upconv4.shape}")
        concat4 = torch.cat([enc4, upconv4], dim=1)

        dec4 = self.dec4(concat4)
        att4 = self.attention4(dec4)
        upconv3 = self.upconv3(att4)
        # Check the shapes and determine padding or cropping needed for upconv3 and enc3
        enc3_shape = enc3.shape
        upconv3_shape = upconv3.shape
        if enc3_shape[2:] != upconv3_shape[2:]:
            # Calculate padding or cropping values
            diff_h = enc3_shape[2] - upconv3_shape[2]
            diff_w = enc3_shape[3] - upconv3_shape[3]
            if diff_h > 0 or diff_w > 0:
                # If enc3 is larger, crop enc3
                enc3 = enc3[:, :, :upconv3_shape[2], :upconv3_shape[3]]
            else:
                # If upconv3 is larger, pad enc3
                pad_h = abs(diff_h) // 2
                pad_w = abs(diff_w) // 2
                enc3 = F.pad(enc3, (pad_w, pad_w, pad_h, pad_h))

        print(f"Shape of enc3: {enc3.shape}")
        print(f"Shape of upconv3: {upconv3.shape}")
        concat3 = torch.cat([enc3, upconv3], dim=1)
        # Rest of the forward method as before

        dec3 = self.dec3(concat3)
        att3 = self.attention3(dec3)
        upconv2 = self.upconv2(att3)
        # Check the shapes and determine padding or cropping needed for upconv2 and enc2
        enc2_shape = enc2.shape
        upconv2_shape = upconv2.shape
        if enc2_shape[2:] != upconv2_shape[2:]:
            # Calculate padding or cropping values
            diff_h = enc2_shape[2] - upconv2_shape[2]
            diff_w = enc2_shape[3] - upconv2_shape[3]
            if diff_h > 0 or diff_w > 0:
                # If enc2 is larger, crop enc2
                enc2 = enc2[:, :, :upconv2_shape[2], :upconv2_shape[3]]
            else:
                # If upconv2 is larger, pad enc2
                pad_h = abs(diff_h) // 2
                pad_w = abs(diff_w) // 2
                enc2 = F.pad(enc2, (pad_w, pad_w, pad_h, pad_h))
        print(f"Shape of enc2: {enc2.shape}")
        print(f"Shape of upconv2: {upconv2.shape}")
        concat2 = torch.cat([enc2, upconv2], dim=1)
        # Rest of the forward method as before
        concat2 = torch.cat([enc2, upconv2], dim=1)

        dec2 = self.dec2(concat2)
        att2 = self.attention2(dec2)
        upconv1 = self.upconv1(att2)
        # Check the shapes and determine padding or cropping needed for upconv1 and enc1
        enc1_shape = enc1.shape
        upconv1_shape = upconv1.shape
        if enc1_shape[2:] != upconv1_shape[2:]:
            # Calculate padding or cropping values
            diff_h = enc1_shape[2] - upconv1_shape[2]
            diff_w = enc1_shape[3] - upconv1_shape[3]
            if diff_h > 0 or diff_w > 0:
                # If enc1 is larger, crop enc1
                enc1 = enc1[:, :, :upconv1_shape[2], :upconv1_shape[3]]
            else:
                # If upconv1 is larger, pad enc1
                pad_h = abs(diff_h) // 2
                pad_w = abs(diff_w) // 2
                enc1 = F.pad(enc1, (pad_w, pad_w, pad_h, pad_h))
        print(f"Shape of enc1: {enc1.shape}")
        print(f"Shape of upconv1: {upconv1.shape}")
        concat1 = torch.cat([enc1, upconv1], dim=1)
        # Rest of the forward method as before

        dec1 = self.dec1(concat1)
        att1 = self.attention1(dec1)
        # Final classification
        final = self.final_conv(att1)
        final = self.global_avg_pool(final)
        return final
